#!/bin/sh
set -eu
cd "$(dirname "$0")"
headers=''
for candidate in "$HOME"/.cargo/git/checkouts/tree-sitter-*/43623ec/crates/language/wasm/include; do
    if [ -d "$candidate" ]; then headers="$candidate"; break; fi
done
if [ -z "$headers" ]; then
  echo 'Tree-sitter WASM headers were not found.' >&2
  exit 1
fi
export CFLAGS_wasm32_unknown_unknown="-I$headers"
export RUSTC_BOOTSTRAP=1
export AR_wasm32_unknown_unknown="$PWD/wasm-ar.sh"
export CARGO_TARGET_DIR=target
export ZIG_GLOBAL_CACHE_DIR="$PWD/target/zig-cache"
export ZIG_LOCAL_CACHE_DIR="$PWD/target/zig-local-cache"
export ZED_SQLITE_CC="$PWD/sqlite-cc.py"
export RUSTFLAGS="--cfg tokio_unstable --remap-path-prefix=$PWD=. --remap-path-prefix=$HOME/.cargo=cargo --remap-path-prefix=$HOME/.rustup=rustup"
export CFLAGS_wasm32_unknown_unknown="$CFLAGS_wasm32_unknown_unknown -ffile-prefix-map=$PWD=. -ffile-prefix-map=$HOME/.cargo=cargo"
cargo +1.98.1 build --target wasm32-unknown-unknown --release --offline -j 4 "$@"
tools/bin/wasm-bindgen --target web --out-dir pkg target/wasm32-unknown-unknown/release/zed_browser_probe.wasm
