# Zed browser port source

Based on zed-industries/zed commit 1a28cff4b409169bac058bca40dfbfeb7621d19b.
https://github.com/zed-industries/zed/tree/1a28cff4b409169bac058bca40dfbfeb7621d19b

The entry point constructs Zed's actual Workspace and MultiWorkspace with GPUI
Web, including the upstream title bar, project panel, panes, tabs and editor.
The browser port adapts filesystem IO, scheduling, settings, parsing, dialogs
and dependency selection. The embedding page provides zedBrowserDialogs; its
implementation is in assets/js/zed/ in the website repository.
Zed's actual TerminalPanel and terminal_view use Alacritty's parser/grid with
an optional authenticated local PTY bridge, zedNativeTerminal. Its JavaScript
transport and pairing dialog are in assets/js/zed/native-terminal.js, and the
local connector is connector/ark_connector.py in the website repository.
Terminal sessions require user pairing and are not restored automatically.
Tasks, language-server processes, Git, and collaboration transport remain
unavailable. Browser documents are separate from native PTY files and persist through the
browser Fs; SQLite workspace metadata currently lives only for the session.

Requirements: Rust 1.98.1 with wasm32-unknown-unknown, Zig, Python 3, and a C/C++
host toolchain for build dependencies. From this directory:

    cargo +1.98.1 fetch --locked --target wasm32-unknown-unknown
    cargo +1.98.1 install wasm-bindgen-cli --version 0.2.120 --locked --root tools
    sh build.sh

Output is written to pkg/. Browser builds use a single-threaded event loop.
See source/LICENSE-GPL and source/LICENSE-APACHE. Each dependency retains its
original license. Modified browser adapter code is distributed under the same
license as its containing crate. No upstream sponsorship is implied.
