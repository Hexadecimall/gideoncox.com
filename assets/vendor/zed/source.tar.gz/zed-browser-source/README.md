# Zed browser port source

Based on zed-industries/zed commit 1a28cff4b409169bac058bca40dfbfeb7621d19b.
https://github.com/zed-industries/zed/tree/1a28cff4b409169bac058bca40dfbfeb7621d19b

The entry point constructs Zed's actual Workspace and MultiWorkspace with GPUI
Web, including the upstream title bar, project panel, panes, tabs and editor.
The browser port adapts filesystem IO, scheduling, settings, parsing, dialogs
and dependency selection. The embedding page provides zedBrowserDialogs; its
implementation is in assets/js/zed/ in the website repository.
Zed's actual TerminalPanel and terminal_view use Alacritty's parser/grid with
an optional authenticated local PTY bridge, zedNativeTerminal. Its JavaScript
transport and pairing dialog are in assets/js/zed/native-terminal.js, and the
local connector is connector/ark_connector.py in the website repository.
Terminal sessions require user pairing and are not restored automatically.
An opt-in zedHost bridge mounts a selected local project, supplies binary process
pipes, and runs installed clangd/rust-analyzer through Zed's upstream LSP client.
The site provides an in-browser Pyright process for Python worktrees stored in
the browser. It uses a bundled worker and standard library stubs and does not
depend on a native connector or Python runtime. See assets/vendor/pyright for
the worker provenance and licenses.
The upstream tasks UI uses native task PTYs. The connector must explicitly enable
process access; it never downloads tools. Browser-only documents still persist
through the browser Fs. SQLite workspace metadata lives only for the session.
Git UI, debugger integration, extension hosting, collaboration and account
services remain unavailable. See the website's packaging/zed/PARITY.md for scope.
The browser build also includes upstream Vim mode, keybindings and mode status,
plus all 22 built-in syntax configurations and their Tree-sitter queries.
Vim is off by default and follows Zed's vim_mode setting. Bundled syntax does
not imply that each language has an available language server.

The Local Assistant dock lives in src/local_assistant.rs and uses the
WebLLM bridge in assets/js/zed/local-assistant.js. The website includes
corresponding WebLLM source links and notices in editor/runtime/webllm.

Requirements: Rust 1.98.1 with wasm32-unknown-unknown, Zig, Python 3, and a C/C++
host toolchain for build dependencies. From this directory:

    cargo +1.98.1 fetch --locked --target wasm32-unknown-unknown
    cargo +1.98.1 install wasm-bindgen-cli --version 0.2.120 --locked --root tools
    sh build.sh

Output is written to pkg/. The project-local Cargo configuration pins release
optimization to level 3, fat LTO and one codegen unit. Browser builds use a
single-threaded event loop.
See source/LICENSE-GPL and source/LICENSE-APACHE. Each dependency retains its
original license. Modified browser adapter code is distributed under the same
license as its containing crate. No upstream sponsorship is implied.
