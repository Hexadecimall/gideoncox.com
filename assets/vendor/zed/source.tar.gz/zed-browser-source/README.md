# Zed browser port source

Based on zed-industries/zed commit 1a28cff4b409169bac058bca40dfbfeb7621d19b.
https://github.com/zed-industries/zed/tree/1a28cff4b409169bac058bca40dfbfeb7621d19b

The entry point constructs Zed's actual Editor with GPUI Web. The browser port
adapts filesystem IO, scheduling, settings, parsing, and dependency selection.
Native terminal processes, language-server processes, Git, and collaboration
transport are not available in this browser build. Documents persist through the
browser Fs; SQLite workspace metadata currently lives only for the session.

Requirements: Rust 1.98.1 with wasm32-unknown-unknown, Zig, Python 3, and a C/C++
host toolchain for build dependencies. From this directory:

    cargo +1.98.1 fetch --locked --target wasm32-unknown-unknown
    cargo +1.98.1 install wasm-bindgen-cli --version 0.2.120 --locked --root tools
    sh build.sh

Output is written to pkg/. Browser builds use a single-threaded event loop.
See source/LICENSE-GPL and source/LICENSE-APACHE. Each dependency retains its
original license. Modified browser adapter code is distributed under the same
license as its containing crate. No upstream sponsorship is implied.
